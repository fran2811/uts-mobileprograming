import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/product.dart';

class ApiService {
  static const String baseUrl = 'https://dummyjson.com/products';

  // Ambil semua produk atau berdasarkan kategori
  Future<List<Product>> fetchProducts({String? category}) async {
    try {
      String url = baseUrl;
      if (category != null && category != 'All') {
        url = '$baseUrl/category/$category';
      }

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> body = json.decode(response.body);
        List<dynamic> listData = body['products'];
        return listData.map((item) => Product.fromJson(item)).toList();
      } else {
        throw Exception('Gagal memuat data');
      }
    } catch (e) {
      throw Exception('Terjadi kesalahan: $e');
    }
  }

  // Ambil daftar kategori produk
  Future<List<String>> fetchCategories() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/categories'));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        // DummyJSON mengembalikan kategori bisa berupa List<String> atau List<Map>
        List<String> categories = ['All'];
        for (var item in data) {
          if (item is String) {
            categories.add(item);
          } else if (item is Map && item['slug'] != null) {
            categories.add(item['slug']);
          }
        }
        return categories;
      } else {
        return ['All'];
      }
    } catch (e) {
      return ['All'];
    }
  }
}
